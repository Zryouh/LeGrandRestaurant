﻿namespace LeGrandRestaurant
{
    public class Client
    {
    }
}
